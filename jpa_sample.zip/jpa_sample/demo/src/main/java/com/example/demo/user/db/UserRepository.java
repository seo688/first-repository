package com.example.demo.user.db;

import com.example.demo.db.SimpleDataRepository;
import com.example.demo.user.model.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

public interface UserRepository extends JpaRepository<UserEntity, Long> {

    // select * from user where score >= ?1
    public List<UserEntity> findAllByScoreGreaterThanEqual(int sc);


    // Query Method 방식
    // select * from user where score >= ?1 and score <= ?2
    public List<UserEntity> findAllByScoreGreaterThanEqualAndScoreLessThanEqual(int min, int max);


    // Using @Query 방식 (JPQL)
    @Query(
            "select u from user u where u.score >= ?1 and u.score <= ?2"
    )
    public List<UserEntity> scoreData(int min, int max);


    // Using @Query 방식 (nativeQuery Named Parameter)
    @Query(
            value = "select * from user as u where u.score >= :minScore and u.score <= :maxScore",
            nativeQuery = true
    )
    public List<UserEntity> scoreDataParam(
            @Param(value="minScore") int min,
            @Param(value="maxScore") int max
    );
}
